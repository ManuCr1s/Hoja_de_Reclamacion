<?php
session_start();
if(!empty($_POST['captcha'])){
    if($_SESSION['codigo'] === $_POST['captcha']){
        echo 'Se envio correctamente el captcha';
    }else{
        echo 'Error: Ingrese correctamente';
    }
}else{
    echo "No ingreso nada";
}